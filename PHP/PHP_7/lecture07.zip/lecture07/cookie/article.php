<?php
//判斷cookie中的ad值是不是1
//不是的話請他去看廣告
if($_COOKIE["ad"]!=1){
    header("Location: ad.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <h3>我是文章</h3>
    <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Suscipit temporibus modi saepe est, eum harum corrupti dignissimos possimus aliquid quod? Autem repellat alias suscipit perspiciatis error fuga tempore eaque itaque?
    Debitis totam facere ipsam inventore! Consequatur error minus culpa provident officia? Necessitatibus ullam quaerat mollitia quia excepturi ea omnis. Harum cum quis repellendus dolor accusamus quo eum aliquam voluptas error.
    Ratione explicabo voluptatum pariatur, quibusdam animi perferendis maxime sint placeat consectetur laborum delectus facilis, doloremque obcaecati a soluta tempora, eos quisquam quae iste harum. Beatae ipsam ipsum dolor qui adipisci.
    Inventore quae molestias exercitationem, est voluptatibus, incidunt excepturi porro aliquam eius iure, amet deserunt mollitia dolore quidem quod ipsa autem ipsam ducimus quibusdam optio harum reiciendis numquam perspiciatis provident. Nobis.
    Accusantium corporis minima provident quidem. Dolorum fugiat qui est cumque, quam inventore fugit provident veritatis at repellendus nam. Laudantium, inventore. Repellendus unde explicabo fugit ab deserunt consequatur fuga doloremque rem?
    Nobis illum architecto hic eligendi provident at iste a odit quisquam non, iure porro aperiam eius sint repudiandae cupiditate sapiente, labore tempora recusandae similique quas amet culpa aliquid! Ea, officia?
    Quibusdam praesentium eaque odit, id reiciendis ipsa repellat atque tenetur modi soluta necessitatibus architecto distinctio ex inventore non, cumque molestias voluptates perspiciatis obcaecati et saepe quam, fugit laboriosam corrupti. Corrupti.
    Nesciunt nihil tempore adipisci aspernatur illo totam magnam commodi omnis. Recusandae quae ullam illum saepe sunt tempora pariatur accusamus ex quia nemo corporis quasi eum molestiae reprehenderit, exercitationem eaque eligendi?
    Velit suscipit vel ut dolore. Perferendis tempora eligendi, obcaecati eos odio ipsa sint in nobis non. Dolorem, consequatur quia consectetur harum libero, officia corrupti accusamus, quaerat in ullam accusantium. A?
    Voluptates eos quidem rem ex at alias consectetur eligendi adipisci esse earum error omnis aliquam a sunt soluta voluptate sequi nisi enim dolor molestiae, reprehenderit doloribus! Dolore cum placeat autem.
    Praesentium aperiam autem error temporibus officiis alias ipsum rerum eligendi vel quibusdam, ab eos expedita recusandae dolor in ullam repellendus non molestiae pariatur distinctio. Id odio quasi est maiores. Incidunt.
    Fugiat ratione nihil sunt quia consequuntur itaque eum, saepe laboriosam optio rerum non unde dolores doloribus hic ipsum! A eveniet odit fugit est doloribus architecto totam adipisci dignissimos, molestiae nisi!
    Fuga doloribus voluptas asperiores unde dolor, distinctio architecto deserunt mollitia suscipit, consequuntur quisquam ea officia deleniti temporibus magni nostrum maiores quidem illum ipsam consectetur cum consequatur incidunt beatae libero. Nesciunt.
    Nesciunt harum accusantium aliquam fugit molestiae recusandae iste molestias consequuntur amet repudiandae optio culpa quaerat quod delectus sed magni at sint quas temporibus cumque, atque perspiciatis dolores pariatur ab. Soluta.
    Asperiores vel amet dignissimos pariatur tempora dolores laudantium ad incidunt, aut ipsa, expedita dolorum exercitationem similique repudiandae. Rem tenetur tempore aspernatur corporis, repellat pariatur ex magni nisi veniam nostrum magnam.
    Alias, adipisci distinctio! Facilis dolorum architecto id deleniti possimus quam voluptatem ad porro vel, ratione exercitationem libero praesentium necessitatibus, maxime officiis ipsum accusamus cupiditate illo fugiat optio commodi alias reprehenderit!
    Id nam numquam ratione saepe illum, perferendis ab at voluptatem aliquam suscipit eveniet autem! Dignissimos, aspernatur facilis corporis blanditiis eum, iure error unde dolore qui ipsam magni voluptates explicabo sed?
    Architecto ratione reiciendis quia nulla, blanditiis atque quod velit nemo magnam est possimus itaque voluptatibus doloribus ex in quaerat aliquid iusto inventore natus sequi dolor commodi. Debitis adipisci iste optio?
    Porro odio repudiandae deleniti, laudantium ad dolorem magni vel sapiente laboriosam, consequatur enim neque officiis eos tempore voluptatibus ut sequi iure ullam dolore. Modi ab sint minima! Officiis, ex rerum?
    Accusamus autem facere excepturi pariatur tempore, non dolores adipisci? Beatae eveniet, voluptate ab nam unde ea aliquam maiores debitis quisquam quidem ipsam facere voluptatibus ducimus quo consequatur eius deserunt excepturi!
    Reiciendis nihil voluptates iste magnam, consequuntur saepe architecto sed quos quas, provident ex blanditiis id a aliquid quaerat. Dolor ex assumenda expedita quas totam qui laborum fuga sapiente distinctio maiores.
    Repudiandae, impedit. Odio aut eligendi repudiandae nostrum architecto, animi mollitia labore sint atque praesentium non libero eos aliquid fugit? Ut dolores asperiores nostrum perspiciatis velit minus, aut illo? Voluptatem, ducimus?
    Rerum provident reprehenderit earum sapiente tenetur velit qui omnis eaque sit fugit maiores fugiat vero animi, culpa quisquam laborum perferendis non mollitia? Molestias nesciunt aspernatur repellendus. Sunt ullam minima eligendi.
    Neque veniam assumenda dicta, voluptatibus qui commodi dolorum quia cumque, dolore nihil corrupti sint accusamus blanditiis ex nulla perferendis alias mollitia. Natus sint, at impedit corrupti voluptatibus dolore deleniti quo.
    Est omnis sunt aliquam rem quasi, odio iusto totam nam labore eos laborum ab qui in accusantium ullam soluta perspiciatis. Quos ut laborum, ad dolore eius incidunt inventore eligendi a.
    Itaque placeat similique nam in repellat odit dignissimos at, distinctio facilis. Dolore labore ipsa totam commodi neque reprehenderit, possimus, omnis in quaerat esse amet vitae provident, inventore ex quas! Enim!
    Ad dolores blanditiis iure nisi, labore aspernatur adipisci dicta perspiciatis obcaecati animi atque est porro at ratione iste dignissimos eaque ipsum, ducimus cupiditate possimus voluptas sunt voluptates enim dolorem? Nulla?
    Beatae minus corrupti dignissimos exercitationem cupiditate non facere enim architecto laborum iure in dolore amet nostrum quisquam, deserunt saepe ducimus eaque, deleniti sint perferendis esse placeat illum. Optio, vero blanditiis!
    Debitis ipsa dicta sapiente quia hic adipisci, inventore recusandae ipsum, quod placeat beatae quos voluptas laborum expedita, impedit sit assumenda nam deserunt? Est quia illum itaque unde cumque officiis eveniet!
    Asperiores inventore temporibus est beatae nobis unde, exercitationem a, mollitia voluptates praesentium necessitatibus aliquid nesciunt explicabo earum sequi laudantium quam. Error totam culpa corporis fugit accusantium quis cupiditate, repellat iusto?
    Nisi hic voluptatibus nemo laudantium natus ea facilis harum iusto labore unde obcaecati delectus distinctio, recusandae, tempore ipsa nihil doloremque illum. Corrupti nobis voluptates voluptas rem aperiam, perferendis atque autem!
    Quibusdam, vitae? Atque ipsa commodi, qui eligendi numquam quos tenetur quae ratione non ducimus officia a? Est id accusantium enim, a perspiciatis aperiam, sequi nihil neque quos delectus iure aliquam!
    Nemo provident corporis temporibus excepturi commodi quis consequatur obcaecati, exercitationem amet illum explicabo? Voluptas, nulla optio sed eius perferendis laboriosam beatae odit eum facilis ducimus, voluptatibus impedit incidunt officia consequuntur?
    Doloremque assumenda sint, est dicta iure at perferendis aliquam! Totam harum facilis aspernatur delectus aperiam amet cumque quasi porro numquam voluptatibus sequi saepe non repudiandae unde dolore, aliquid enim aliquam.
    Doloremque voluptatibus perspiciatis aut cupiditate? A officia nostrum voluptatum alias minus commodi est qui tempora adipisci repellat iste error perferendis delectus sed facere rem officiis, ut animi. Fugiat, suscipit facilis.
    Quos maiores adipisci, animi in sit error esse doloribus optio quam aspernatur repellendus consequatur numquam expedita vel earum id magni obcaecati quo vero ex iste blanditiis, amet aliquam! Harum, placeat!
    Voluptas fuga velit sint, facere natus non, dicta minima est voluptatibus doloremque ipsum repudiandae hic deserunt alias eveniet, quasi repellendus sit atque autem sapiente at! Voluptatibus, ad tenetur! Blanditiis, eos?
    Voluptates exercitationem amet quisquam voluptatibus ducimus explicabo quasi provident! Voluptate atque corrupti at earum odio perferendis consequatur ab facere. Sunt magni est eaque vitae fugit aperiam. Adipisci asperiores perspiciatis itaque!
    Ut, minus laboriosam. Illo consequatur voluptas harum omnis rerum sint nemo! Error nemo eveniet nisi doloribus aperiam deleniti unde illo, maxime necessitatibus, mollitia voluptates natus alias recusandae! Expedita, fuga aspernatur?
    Ab provident, obcaecati cupiditate minus officiis adipisci est deserunt, illum quae aliquid dolores vel dignissimos eum quia debitis impedit. Possimus, provident? Illum vel consequuntur sint blanditiis beatae nesciunt, maiores quaerat?
    Explicabo maxime optio, totam dolore quam unde placeat voluptates accusamus quasi amet nam, vel et, molestias alias dolorem deleniti quod eius labore eos quae non voluptatem assumenda eveniet. Nihil, dignissimos.
    Reiciendis amet placeat commodi recusandae facilis architecto repudiandae? Pariatur nobis magni eligendi vel, quas neque eius delectus quibusdam, corrupti, ea ratione alias facere voluptatibus incidunt nihil consectetur. Maxime, quam autem?
    Vero expedita hic id temporibus. Totam ullam sequi est magni nisi. Magni amet quis qui illo doloremque, distinctio magnam architecto nisi aliquid nam repellat libero debitis consequuntur? Quis, nemo sequi.
    A, quisquam ex pariatur quidem accusamus natus ratione soluta minus repellendus hic nemo nisi doloribus quam unde enim voluptatum ullam rem. Non, esse dolorem nam perspiciatis consequatur suscipit dolorum aperiam.
    Libero repellendus nostrum officia nihil facere iure. Nobis aperiam recusandae dolore? Deleniti nemo perferendis ipsa quos at, ad ullam ut placeat distinctio consectetur numquam culpa unde earum debitis ipsam recusandae!
    Laboriosam iure id veritatis enim provident! Aut excepturi doloribus officiis quos dicta eius rem saepe vero, odit ex similique quis labore quod, facilis exercitationem corporis suscipit facere magnam architecto omnis?
    Accusantium, velit voluptatem, nisi et praesentium quos libero autem aperiam expedita in natus, dolore blanditiis asperiores deleniti. Possimus ullam porro fugiat sint ipsam perspiciatis nostrum cumque, minima nihil pariatur earum!
    Harum rerum praesentium officiis reiciendis? Dolorem perspiciatis distinctio laudantium? Quidem iure, pariatur quae eum fugiat aliquid ex, qui omnis commodi alias eveniet vitae odio quaerat, velit similique cum dolore necessitatibus!
    Blanditiis eius quae quidem, nulla commodi explicabo aliquam corrupti tempore saepe debitis dolores voluptatem incidunt esse illum consequuntur dignissimos voluptates sint eos voluptate! Dicta commodi aliquid similique! Libero, soluta fugit!
    Consequuntur nulla corrupti qui adipisci dolorum esse laborum similique iste, tempore praesentium laudantium aspernatur voluptas rerum earum eveniet amet officia consequatur dolores accusamus placeat perferendis. Repudiandae modi dolor sequi unde.</p>
</body>
</html>