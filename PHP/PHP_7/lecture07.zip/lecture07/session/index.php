<?php
session_start();
if(!isset($_SESSION["loginStatus"])){
    header("Location: login.html");
}

if(isset($_GET["action"])){
    // unset($_SESSION["loginStatus"]);
    session_destroy();
    echo "<script>
        alert('登出成功');
        window.location = 'login.html';
        </script>";
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <h3>首頁</h3>
    <p>歡迎光臨 <?= $_SESSION["userName"]?></p>
    <a href="index.php?action=logout">登出</a>
</body>
</html>