<?php
session_start();
//帳密
$user= "elsa";
$pwd = "elsa123";

$userName = $_POST["username"];
$userPwd = $_POST["password"];

if(($userName == $user)&&($userPwd==$pwd)){
    $_SESSION["loginStatus"] = 1;
    $_SESSION["userName"] = $userName;
    header("Location: index.php");
}else{
    echo "<script>
            alert('帳密錯誤');
            window.location='login.html';
        </script>";
}
?>