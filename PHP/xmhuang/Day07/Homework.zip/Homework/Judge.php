<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Judge</title>
</head>
<body>
<center>
	<h1>判斷結果</h1>
	國文
	<?php echo $_GET["CHscore"]."分"; ?>
	<br>
	等級: 
	<?php
		if ($_GET["CHscore"]>=90) {
			echo "A";
		}
		elseif ($_GET["CHscore"]>=80&&$_GET["CHscore"]<90) {
			echo "B";
		}
		elseif ($_GET["CHscore"]>=70&&$_GET["CHscore"]<80) {
			echo "C";
		}
		elseif ($_GET["CHscore"]>=60&&$_GET["CHscore"]<70) {
			echo "D";
		}
		else{
			echo "E";
		}
	?>
	<br>
	英文
	<?php echo $_GET["CHscore"]."分" ;?>
	<br>
	等級: 
	<?php
		if ($_GET["ENscore"]>=90) {
			echo "A";
		}
		elseif ($_GET["ENscore"]>=80&&$_GET["ENscore"]<90) {
			echo "B";
		}
		elseif ($_GET["ENscore"]>=70&&$_GET["ENscore"]<80) {
			echo "C";
		}
		elseif ($_GET["ENscore"]>=60&&$_GET["ENscore"]<70) {
			echo "D";
		}
		else{
			echo "E";
		}
	?>
</center>
</body>
</html>