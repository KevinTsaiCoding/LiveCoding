<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>ScoreJudge</title>
</head>
<body>
<center>
	<h2>請輸入成績</h2>
	<h3>
	<form method="get" action="judge.php">
	國文&nbsp;<input type="number" name="CHscore" min="0" max="100">
	<br>
	英文&nbsp;<input type="number" name="ENscore" min="0" max="100">
	<br>
	<input type="submit" name="submit">
	</form>
</h3>
</center>
</body>
</html>