#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<stdint.h>
#include"xxtea.h"

int xxtea_enc(char *pt, int size, char **ct, char *key) {
	size_t ct_size;
	*ct = xxtea_encrypt(pt, size, key, &ct_size);
	if(*ct == NULL)
		return -1;
	return ct_size;
}

int xxtea_dec(char *ct, int size, char **pt, char *key) {
	size_t pt_size;
	*pt = xxtea_decrypt(ct, size, key, &pt_size);
	if(*pt == NULL)
		return -1;
	return pt_size;
}

int main() {
	char *msg = "hello";
	char *ct = NULL;

	for(int i=0;i<strlen(msg);i++)
		printf("%c", msg[i]);
	printf("\n");

	int size = xxtea_enc(msg, strlen(msg), &ct, "1234");
	if(size == -1) {
		printf("Encrypt failure!\n");
		return EXIT_FAILURE;
	}
	for(int i=0;i<size;i++)
		printf("%c", ct[i]);
	printf("\n");

	char *pt = NULL;
	size = xxtea_dec(ct, size, &pt, "1234");
	if(size == -1) {
		printf("Decrypt failure!\n");
		return EXIT_FAILURE;
	}
	for(int i=0;i<size;i++)
		printf("%c", pt[i]);
	printf("\n");

	return EXIT_SUCCESS;
}
